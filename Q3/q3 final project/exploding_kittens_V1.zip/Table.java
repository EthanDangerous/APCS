import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class Table extends JPanel implements ActionListener, MouseListener, KeyListener {

	public JButton getCard;
    public JButton playHand;
    public JButton playerSwitch;
    public JButton endTurn;
    public JButton rulesButton;
    public JButton closeButton;
    private CardGame cardGame;
    private Graphics g;
    public boolean viewingRules = false;

    public Table() {
        cardGame = new CardGame(this);
        //setup buttons
        setLayout(null);

        getCard = new JButton("Get Card");
        getCard.setBounds(400, 250, 100, 30); //x,y,width,height
        getCard.addActionListener(this);
        add(getCard);

        playHand = new JButton("Play Hand");
        playHand.setBounds(400, 280, 100, 30); //x,y,width,height
        playHand.addActionListener(this);
        add(playHand);

        playerSwitch = new JButton("Switch Player");
        playerSwitch.setBounds(500, 250, 100, 30); //x,y,width,height
        playerSwitch.addActionListener(this);
        add(playerSwitch);

        rulesButton = new JButton("Rules/Hands");
        rulesButton.setBounds(500, 280, 100, 30); //x,y,width,height
        rulesButton.addActionListener(this);
        add(rulesButton);

        closeButton = new JButton("X");
        closeButton.setBounds(660, 30, 40, 40); //x,y,width,height
        closeButton.addActionListener(this);
        add(closeButton);
        closeButton.setVisible(false);

        addMouseListener(this);
        setFocusable(true);
        addKeyListener(this);
    }

    public Dimension getPreferredSize() {
        //Sets the size of the panel
        return new Dimension(1000, 600);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);


        cardGame.drawGame(g);
        cardGame.addCardButton(this);
        this.g = g;
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == playHand) {
            if(cardGame.currentPlayer == 1){
                for(int i = 0; i<cardGame.playersCard.size(); i++){
                    if(i == 0 && cardGame.playersCard.get(i).getSelected()){
                        cardGame.playersCard.get(i).highlight();
                        cardGame.getDiscard().add(cardGame.playersCard.remove(i));
                    }
                    if(i != 0 && cardGame.playersCard.get(i).getSelected()){
                        cardGame.playersCard.get(i).highlight();
                        cardGame.getDiscard().add(cardGame.playersCard.remove(i));
                        i--;
                    }
                }
            }else if(cardGame.currentPlayer == 2){
                for(int i = 0; i<cardGame.playersCard2.size(); i++){
                    if(i == 0 && cardGame.playersCard2.get(i).getSelected()){
                        cardGame.playersCard2.get(i).highlight();
                        cardGame.getDiscard().add(cardGame.playersCard2.remove(i));
                    }
                    if(i != 0 && cardGame.playersCard2.get(i).getSelected()){
                        cardGame.playersCard2.get(i).highlight();
                        cardGame.getDiscard().add(cardGame.playersCard2.remove(i));
                        i--;
                    }
                }
            }
            repaint();
        }
        if (e.getSource() == getCard) {
            //add a card to the playersDeck
            if (!cardGame.viewingCard) {
                cardGame.getCard();
            }
            if(cardGame.getDeck().size() == 0){
                getCard.setEnabled(false);
            }
            //remove the top from the deck
            //call repaint to update the paintComponent
//			System.out.println(cardGame.getGap());
        }
        if (e.getSource() == rulesButton) {
            closeButton.setBounds(960, 0, 40, 40); //x,y,width,height
            closeButton.setVisible(true);
            if (!viewingRules) {
                viewingRules = true;
            }
        }
        if (e.getSource() == playerSwitch) {
            //add a card to the playersDeck
            if(cardGame.currentPlayer == 1){
                cardGame.currentPlayer = 2;
                for(int i = 0; i<cardGame.playersCard.size(); i++){
                    if(cardGame.playersCard.get(i).isSelected){
                        cardGame.playersCard.get(i).highlight();
                    }
                }
            }else if(cardGame.currentPlayer == 2){
                cardGame.currentPlayer = 1;
                for(int i = 0; i<cardGame.playersCard2.size(); i++){
                    if(cardGame.playersCard2.get(i).isSelected){
                        cardGame.playersCard2.get(i).highlight();
                    }
                }
            }
            //remove the top from the deck
            //call repaint to update the paintComponent
//			System.out.println(cardGame.getGap());
        }
        if (e.getSource() == closeButton) {
            viewingRules = false;
            cardGame.viewingCard = false;
            for (int j = 0; j < cardGame.playersCard.size(); j++) {
                cardGame.playersCard.get(j).viewingCard = false;
                if(cardGame.playersCard.get(j).getSelected()){
                    cardGame.playersCard.get(j).viewButton.setVisible(true);
                    cardGame.playersCard.get(j).buttonEnabled(true);
                }
            }
            for (int j = 0; j < cardGame.playersCard2.size(); j++) {
                cardGame.playersCard2.get(j).viewingCard = false;
                if(cardGame.playersCard2.get(j).getSelected()){
                    cardGame.playersCard2.get(j).viewButton.setVisible(true);
                    cardGame.playersCard2.get(j).buttonEnabled(true);
                }
            }
            getCard.setVisible(true);
            playerSwitch.setVisible(true);
            playHand.setVisible(true);
            rulesButton.setVisible(true);
            closeButton.setVisible(false);
            if(cardGame.getDeck().size()>0){
                getCard.setEnabled(true);
            }
        }
        requestFocus();
        setFocusable(true);
        repaint();
    }


    public void mousePressed(MouseEvent e) {
        //Print location of x and y
        System.out.println("X: " + e.getX() + ", Y: " + e.getY());
        cardGame.selectCard(e.getX(), e.getY());
        repaint();
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseClicked(MouseEvent e) {
    }



    public void keyPressed(KeyEvent e) {
        //To test this, make sure you click on the graphical window.
        //Do not click on the console window.
        //You can see the number for each key by looking at the output below.
//        System.out.println("key code: " + e.getKeyCode());

        if(viewingRules){
            closeButton.setVisible(true);
            if (e.getKeyCode() == 38 && cardGame.rulesY != 0) {
                cardGame.rulesY += 25;
            }
            if (e.getKeyCode() == 40 && cardGame.rulesY != -900) {
                cardGame.rulesY -= 25;
            }
            if (e.getKeyCode() == 39 || e.getKeyCode() == 37) {
                getCard.setVisible(false);
                playerSwitch.setVisible(false);
                playHand.setVisible(false);
                rulesButton.setVisible(false);
                for (int j = 0; j < cardGame.playersCard.size(); j++) {
                    cardGame.playersCard.get(j).buttonEnabled(false);
                    cardGame.playersCard.get(j).viewButton.setVisible(false);
                }
                for (int j = 0; j < cardGame.playersCard2.size(); j++) {
                    cardGame.playersCard2.get(j).buttonEnabled(false);
                    cardGame.playersCard2.get(j).viewButton.setVisible(false);
                }
                if(cardGame.rulePage == 1){
                    cardGame.rulesY = 0;
                    cardGame.rulePage = 2;
                }else if(cardGame.rulePage == 2){
                    cardGame.rulesY = 0;
                    cardGame.rulePage = 1;
                }
            }
        }
        repaint();
    }

    public void keyReleased(KeyEvent e) {}
    public void keyTyped(KeyEvent e) {}
}
